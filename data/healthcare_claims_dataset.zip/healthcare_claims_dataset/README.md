# Synthetic Healthcare Claims Dataset

This dataset was generated specifically for the Healthcare Claims Databricks Lakehouse portfolio project.

## Files

- claims/claims.csv
- members/members.csv
- providers/providers.csv
- procedures/procedures.csv
- diagnoses/diagnoses.csv
- payments/payments.csv

## Purpose

The dataset is synthetic and contains intentionally introduced data-quality issues such as NULL foreign keys, invalid foreign keys, negative claim amounts, invalid dates, unknown statuses, and duplicate claims. These issues are included so the Databricks project can demonstrate data validation, rejected-record handling, and data-quality reporting.

## Important

This is synthetic data and does not contain real patient information.
